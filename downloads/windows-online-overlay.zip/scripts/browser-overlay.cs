namespace SmallPatch {
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Automation;
using System.Windows.Forms;

// The page supplies only its own transparent animation. This window displays
// that strip over the bound Edge chrome and passes input to Edge underneath.
public sealed class PatchBrowserOverlay : Form, IPatchOverlay {
    public sealed class PageState {
        public string session;
        public string title;
        public bool visible;
        public bool focused;
        public bool enabled;
        public double viewportWidth;
        public double viewportHeight;
        public double scale;
    }

    sealed class ChromeControl {
        public string kind;
        public int x, y, width, height;
    }

    sealed class ChromePointer {
        public int x, y;
        public bool down;
    }

    sealed class ChromePoint {
        public int x, y;
    }

    sealed class ChromeLayout {
        public int width, height;
        public ChromeControl[] controls = new ChromeControl[0];
        public ChromePoint root;
        public ChromeControl closeButton;
        public string key = "";
        public string revision = "0";
    }

    sealed class AutomationLayout {
        public IntPtr target;
        public int clientWidth, clientHeight, captionOffset;
        public double viewportWidth, viewportHeight, scale;
        public int height;
        public ChromeControl[] controls;
    }

    readonly object sync = new object();
    readonly System.Windows.Forms.Timer timer;
    PageState state;
    ChromeLayout layout = new ChromeLayout();
    AutomationLayout automation;
    IntPtr target;
    long heartbeat;
    long lastAutomation;
    long revision;
    bool readingAutomation;
    bool active;
    bool closing;
    byte[] pendingFrame;
    string pendingRevision;
    string displayedRevision;
    long receivedFrames;
    long displayedFrames;
    long droppedFrames;
    string lastError = "";
    Native.RECT strip;

    public PatchBrowserOverlay() {
        Text = "A Small Patch Browser Overlay";
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        Size = new Size(1, 1);
        timer = new System.Windows.Forms.Timer();
        timer.Interval = 33;
        timer.Tick += delegate { TickOverlay(); };
        timer.Start();
        CreateHandle();
    }

    public static void EnableDpiAwareness() {
        try {
            Native.SetProcessDpiAwarenessContext(new IntPtr(-4));
            Native.SetThreadDpiAwarenessContext(new IntPtr(-4));
        }
        catch (EntryPointNotFoundException) { Native.SetProcessDPIAware(); }
    }

    protected override bool ShowWithoutActivation { get { return true; } }

    protected override void SetVisibleCore(bool value) {
        base.SetVisibleCore(value && displayedRevision != null);
    }

    protected override CreateParams CreateParams {
        get {
            CreateParams value = base.CreateParams;
            value.ExStyle |= 0x00080000 | 0x00000020 | 0x08000000 | 0x00000080;
            return value;
        }
    }

    protected override void OnHandleCreated(EventArgs e) {
        base.OnHandleCreated(e);
        Native.RegisterHotKey(Handle, 1, 0x0001 | 0x0002 | 0x4000, 0x79);
    }

    protected override void WndProc(ref Message message) {
        if (message.Msg == 0x0084) { message.Result = new IntPtr(-1); return; }
        if (message.Msg == 0x0021) { message.Result = new IntPtr(3); return; }
        if (message.Msg == 0x0312 && message.WParam == new IntPtr(1)) { Close(); return; }
        base.WndProc(ref message);
    }

    protected override void Dispose(bool disposing) {
        if (disposing && !closing) {
            lock (sync) { closing = true; active = false; pendingFrame = null; }
            timer.Stop();
            timer.Dispose();
            if (IsHandleCreated) Native.UnregisterHotKey(Handle, 1);
        }
        base.Dispose(disposing);
    }

    static bool Finite(double value) { return !Double.IsNaN(value) && !Double.IsInfinity(value); }

    static bool Valid(PageState value) {
        return value != null && !String.IsNullOrEmpty(value.session) && value.session.Length <= 100
            && !String.IsNullOrEmpty(value.title) && value.title.Length <= 300
            && Finite(value.viewportWidth) && value.viewportWidth >= 100 && value.viewportWidth <= 20000
            && Finite(value.viewportHeight) && value.viewportHeight >= 80 && value.viewportHeight <= 20000
            && Finite(value.scale) && value.scale >= .25 && value.scale <= 8;
    }

    static bool MatchesEdge(IntPtr window, string title) {
        if (window == IntPtr.Zero || Native.IsIconic(window) || !Native.IsWindowVisible(window)) return false;
        uint processId;
        Native.GetWindowThreadProcessId(window, out processId);
        try {
            using (Process process = Process.GetProcessById((int)processId)) {
                if (!String.Equals(process.ProcessName, "msedge", StringComparison.OrdinalIgnoreCase)) return false;
            }
        } catch (ArgumentException) { return false; }
          catch (InvalidOperationException) { return false; }
          catch (System.ComponentModel.Win32Exception) { return false; }
        StringBuilder text = new StringBuilder(1024);
        Native.GetWindowText(window, text, text.Capacity);
        string actual = text.ToString();
        return actual == title || actual.StartsWith(title + " - ", StringComparison.Ordinal)
            || actual.StartsWith(title + " — ", StringComparison.Ordinal)
            || actual.StartsWith(title + " – ", StringComparison.Ordinal);
    }

    public string State(string json) {
        PageState incoming;
        try { incoming = new JavaScriptSerializer().Deserialize<PageState>(json); }
        catch (Exception error) { throw new ArgumentException("Invalid overlay state.", error); }
        if (!Valid(incoming)) throw new ArgumentException("Invalid overlay state.");
        IntPtr foreground = Native.GetForegroundWindow();
        bool foregroundMatches = incoming.visible && incoming.enabled && MatchesEdge(foreground, incoming.title);
        bool eligible = incoming.focused && foregroundMatches;
        lock (sync) {
            if (closing) return "{\"available\":false,\"active\":false}";
            bool sameSession = state != null && state.session == incoming.session;
            if (eligible && (!sameSession || target != foreground)) {
                target = foreground;
                automation = null;
                lastAutomation = 0;
                pendingFrame = null;
                displayedRevision = null;
                layout = new ChromeLayout();
                active = false;
                state = incoming;
                heartbeat = Environment.TickCount & Int32.MaxValue;
            } else if (sameSession) {
                state = incoming;
                heartbeat = Environment.TickCount & Int32.MaxValue;
                if (!incoming.visible || !incoming.enabled) {
                    active = false;
                    pendingFrame = null;
                }
            }
            bool ownsSession = state != null && state.session == incoming.session;
            return new JavaScriptSerializer().Serialize(new {
                available = true,
                active = ownsSession && active && incoming.visible && incoming.enabled,
                width = ownsSession ? layout.width : 0,
                height = ownsSession ? layout.height : 0,
                revision = ownsSession ? layout.revision : "0",
                controls = ownsSession ? layout.controls : new ChromeControl[0],
                root = ownsSession ? layout.root : null,
                closeButton = ownsSession ? layout.closeButton : null,
                pointer = ownsSession && active && foregroundMatches && target == foreground ? ReadPointer(strip) : null
            });
        }
    }

    static ChromePointer PointerAt(Native.RECT bounds, Native.POINT point) {
        if (point.X < bounds.Left || point.X >= bounds.Right || point.Y < bounds.Top || point.Y >= bounds.Bottom) return null;
        return new ChromePointer { x = point.X - bounds.Left, y = point.Y - bounds.Top };
    }

    static ChromePointer ReadPointer(Native.RECT bounds) {
        IntPtr previousDpi = IntPtr.Zero;
        try {
            // State requests run on server threads, which may inherit a different
            // DPI context from the Forms thread. Match the physical toolbar bounds.
            try { previousDpi = Native.SetThreadDpiAwarenessContext(new IntPtr(-4)); }
            catch (EntryPointNotFoundException) { }
            Native.POINT point;
            if (!Native.GetCursorPos(out point)) return null;
            ChromePointer pointer = PointerAt(bounds, point);
            if (pointer != null) pointer.down = (Native.GetAsyncKeyState(0x01) & 0x8000) != 0;
            return pointer;
        } finally {
            if (previousDpi != IntPtr.Zero) Native.SetThreadDpiAwarenessContext(previousDpi);
        }
    }

    public bool Frame(byte[] png, string session, string frameRevision) {
        if (png.Length < 24 || png[0] != 137 || png[1] != 80 || png[2] != 78 || png[3] != 71
            || png[4] != 13 || png[5] != 10 || png[6] != 26 || png[7] != 10) throw new ArgumentException("Invalid PNG frame.");
        int width = ReadInt(png, 16), height = ReadInt(png, 20);
        if (width < 1 || height < 1 || width > 8192 || height > 1024 || (long)width * height > 8388608)
            throw new ArgumentException("Invalid PNG dimensions.");
        lock (sync) {
            if (!active || state == null || state.session != session || frameRevision != layout.revision
                || width != layout.width || height != layout.height || closing) { droppedFrames++; return false; }
            receivedFrames++;
            if (pendingFrame != null) droppedFrames++;
            pendingFrame = png;
            pendingRevision = frameRevision;
            return true;
        }
    }

    static int ReadInt(byte[] value, int offset) {
        return (value[offset] << 24) | (value[offset + 1] << 16) | (value[offset + 2] << 8) | value[offset + 3];
    }

    public string Diagnostics() {
        lock (sync) {
            int style = IsHandleCreated ? Native.GetWindowLong(Handle, -20) : 0;
            return new JavaScriptSerializer().Serialize(new {
                active = active,
                shown = IsHandleCreated && Native.IsWindowVisible(Handle),
                target = target.ToInt64(),
                overlay = IsHandleCreated ? Handle.ToInt64() : 0,
                width = layout.width,
                height = layout.height,
                x = strip.Left,
                y = strip.Top,
                revision = layout.revision,
                controls = layout.controls.Length,
                receivedFrames = receivedFrames,
                displayedFrames = displayedFrames,
                droppedFrames = droppedFrames,
                lastError = lastError,
                clickThrough = (style & 0x00000020) != 0,
                noActivate = (style & 0x08000000) != 0,
                layered = (style & 0x00080000) != 0
            });
        }
    }

    static Native.RECT ClientBounds(IntPtr window) {
        Native.RECT bounds;
        Native.GetClientRect(window, out bounds);
        Native.POINT origin = new Native.POINT();
        Native.ClientToScreen(window, ref origin);
        bounds.Right += origin.X;
        bounds.Bottom += origin.Y;
        bounds.Left = origin.X;
        bounds.Top = origin.Y;
        return bounds;
    }

    static Native.RECT IncludeCaption(Native.RECT client, Native.RECT frame) {
        // Keep the content's horizontal coordinates so page/native seam contacts
        // agree. DWM's visible top includes caption controls, not resize shadows.
        if (frame.Right > frame.Left && frame.Bottom > frame.Top
            && frame.Top <= client.Top && client.Top - frame.Top <= 240) client.Top = frame.Top;
        return client;
    }

    static Native.RECT ChromeBounds(IntPtr window, Native.RECT client) {
        Native.RECT frame;
        try {
            if (Native.DwmGetWindowAttribute(window, 9, out frame, Marshal.SizeOf(typeof(Native.RECT))) == 0)
                return IncludeCaption(client, frame);
        } catch (DllNotFoundException) { }
          catch (EntryPointNotFoundException) { }
        return client;
    }

    void TickOverlay() {
        try { RefreshOverlay(); }
        catch (Exception error) {
            lock (sync) { active = false; lastError = error.GetType().Name + ": " + error.Message; }
            Hide();
        }
    }

    void RefreshOverlay() {
        PageState current;
        IntPtr window;
        long now = Environment.TickCount & Int32.MaxValue;
        lock (sync) {
            current = state;
            window = target;
            if (closing || current == null || !current.enabled || !current.visible || now - heartbeat > 3500 || now < heartbeat) {
                active = false;
                pendingFrame = null;
                Hide();
                return;
            }
        }
        if (Native.GetForegroundWindow() != window || !MatchesEdge(window, current.title)) {
            lock (sync) { active = false; pendingFrame = null; }
            Hide();
            return;
        }
        Native.RECT client = ClientBounds(window);
        Native.RECT chrome = ChromeBounds(window, client);
        int captionOffset = client.Top - chrome.Top;
        int width = client.Right - client.Left;
        int clientHeight = client.Bottom - client.Top;
        int chromeHeight = captionOffset + (int)Math.Round(clientHeight - current.viewportHeight * current.scale);
        ChromeControl[] controls = null;
        lock (sync) {
            if (automation != null && automation.target == window && automation.clientWidth == width
                && automation.clientHeight == clientHeight && automation.viewportWidth == current.viewportWidth
                && automation.viewportHeight == current.viewportHeight && automation.scale == current.scale
                && automation.captionOffset == captionOffset) {
                chromeHeight = automation.height;
                controls = automation.controls;
            }
        }
        if (width < 100 || width > 8192 || chromeHeight < 20 || chromeHeight > 600 || (long)width * chromeHeight > 8388608) {
            lock (sync) { active = false; pendingFrame = null; }
            Hide();
            return;
        }
        if (controls == null) controls = FallbackControls(window, width, chromeHeight, captionOffset);
        ChromeControl closeButton = FindCloseButton(controls, width, chromeHeight);
        ChromePoint rootPoint = RootPoint(closeButton, width, chromeHeight, WindowScale(window));
        string key = new JavaScriptSerializer().Serialize(new { width = width, height = chromeHeight, controls = controls,
            root = rootPoint, closeButton = closeButton });
        byte[] frame;
        string frameRevision;
        lock (sync) {
            if (state != current || target != window) return;
            strip = new Native.RECT { Left = chrome.Left, Top = chrome.Top, Right = chrome.Right, Bottom = chrome.Top + chromeHeight };
            if (layout.key != key) {
                layout = new ChromeLayout { width = width, height = chromeHeight, controls = controls, root = rootPoint,
                    closeButton = closeButton, key = key,
                    revision = (++revision).ToString(System.Globalization.CultureInfo.InvariantCulture) };
                pendingFrame = null;
                displayedRevision = null;
                Hide();
            }
            active = true;
            frame = pendingFrame;
            frameRevision = pendingRevision;
            pendingFrame = null;
            if (!readingAutomation && now - lastAutomation >= 1000) {
                readingAutomation = true;
                lastAutomation = now;
                ThreadPool.QueueUserWorkItem(delegate { ReadAutomation(window, current, client, chrome); });
            }
        }
        if (frame != null && frameRevision == layout.revision) {
            Present(frame, strip);
            lock (sync) { displayedRevision = frameRevision; displayedFrames++; lastError = ""; }
        }
        if (displayedRevision == layout.revision) {
            if (!Visible) Show();
            Native.SetWindowPos(Handle, new IntPtr(-1), chrome.Left, chrome.Top, width, chromeHeight, 0x0010 | 0x0040);
        }
    }

    static double WindowScale(IntPtr window) {
        double scale = 1;
        try { scale = Math.Max(1, Native.GetDpiForWindow(window) / 96.0); } catch (EntryPointNotFoundException) { }
        return scale;
    }

    static ChromeControl[] FallbackControls(IntPtr window, int width, int height, int captionOffset) {
        double scale = WindowScale(window);
        int tabHeight = (int)Math.Round(36 * scale);
        int rowHeight = (int)Math.Round(36 * scale);
        var controls = new List<ChromeControl>();
        if (height >= tabHeight + rowHeight) {
            controls.Add(new ChromeControl { kind = "address", x = (int)(90 * scale), y = captionOffset + tabHeight + (int)(4 * scale),
                width = Math.Max(80, width - (int)(370 * scale)), height = rowHeight - (int)(6 * scale) });
            controls.Add(new ChromeControl { kind = "tab", x = (int)(8 * scale), y = captionOffset + (int)(3 * scale),
                width = Math.Min((int)(240 * scale), width / 3), height = tabHeight - (int)(3 * scale) });
        }
        // Even before UI Automation returns, the network can follow the title
        // buttons' upper edges without crossing the minimize/maximize/X glyphs.
        int buttonWidth = Math.Min(width / 3, (int)Math.Round(46 * scale));
        int captionHeight = Math.Min(height, captionOffset >= 18 * scale ? captionOffset : tabHeight);
        for (int index = 3; index >= 1; index--) {
            controls.Add(new ChromeControl { kind = "button", x = width - index * buttonWidth, y = 0,
                width = buttonWidth, height = captionHeight });
        }
        return controls.ToArray();
    }

    static ChromeControl FindCloseButton(ChromeControl[] controls, int width, int height) {
        double scale = Math.Max(.65, Math.Min(2.5, height / 118.0));
        ChromeControl result = null;
        foreach (ChromeControl box in controls) {
            if (box.kind != "button" || box.width < 18 * scale || box.width > 100 * scale
                || box.height < 15 * scale || box.height > 65 * scale || box.y > 12 * scale
                || box.x < width * .75 || box.x + box.width < width - 32 * scale) continue;
            if (result == null || box.x + box.width > result.x + result.width) result = box;
        }
        return result;
    }

    static ChromePoint RootPoint(ChromeControl closeButton, int width, int height, double scale) {
        // Keep the source visible above the X, well inside the right clipping
        // edge. Its first vessel follows the button's rim around the glyph.
        double x = closeButton == null ? width - 24 * scale : closeButton.x + closeButton.width * .5;
        double y = (closeButton == null ? 0 : closeButton.y) + 2 * scale;
        return new ChromePoint { x = Math.Max(0, Math.Min(width - 2, (int)Math.Round(x))),
            y = Math.Max(0, Math.Min(height - 2, (int)Math.Round(y))) };
    }

    static bool InChrome(System.Windows.Rect bounds, Native.RECT chrome) {
        return !bounds.IsEmpty && bounds.Width >= 8 && bounds.Height >= 8
            && bounds.Top >= chrome.Top - 2 && bounds.Bottom <= chrome.Bottom + 2
            && bounds.Left >= chrome.Left - 2 && bounds.Right <= chrome.Right + 2;
    }

    static bool BookmarkItem(System.Windows.Rect bounds, Native.RECT chrome, int addressBottom, double scale) {
        return InChrome(bounds, chrome) && addressBottom > 0 && bounds.Top - chrome.Top >= addressBottom - 2
            && bounds.Width < Math.Min((chrome.Right - chrome.Left) * .6, 700 * scale)
            && bounds.Height <= 64 * scale;
    }

    static ChromeControl MapControl(string type, System.Windows.Rect bounds, Native.RECT chrome, int addressBottom, double scale) {
        if (!InChrome(bounds, chrome)) return null;
        string kind;
        if (type == "Edit" && bounds.Width > 160 * scale) kind = "address";
        else if (type == "TabItem") kind = "tab";
        else if ((type == "Button" || type == "MenuItem" || type == "Hyperlink" || type == "ListItem")
            && BookmarkItem(bounds, chrome, addressBottom, scale)) kind = "bookmark";
        else if (type == "Button" && addressBottom > 0 && bounds.Top - chrome.Top >= addressBottom - 2) return null;
        else if (type == "Button" || type == "Edit") kind = "button";
        else return null;
        // Neither a toolbar nor a row-sized button/container is an individual
        // bookmark. Masking one would hide the entire space around the items.
        if (kind != "address" && bounds.Width >= (chrome.Right - chrome.Left) * .8) return null;
        return new ChromeControl { kind = kind, x = (int)Math.Round(bounds.Left - chrome.Left),
            y = (int)Math.Round(bounds.Top - chrome.Top), width = (int)Math.Round(bounds.Width), height = (int)Math.Round(bounds.Height) };
    }

    static System.Windows.Rect BookmarkParentBounds(System.Windows.Rect bounds, System.Windows.Rect parent,
        Native.RECT chrome, int addressBottom, double scale) {
        // A link may expose only its text, while its MenuItem/Button/Custom
        // parent owns the complete clickable box. Do not promote to the row.
        if (BookmarkItem(parent, chrome, addressBottom, scale) && parent.Contains(bounds)
            && parent.Height <= Math.Max(bounds.Height + 16 * scale, bounds.Height * 1.65)) return parent;
        return bounds;
    }

    static ChromeControl[] DistinctControls(List<ChromeControl> boxes) {
        var result = new List<ChromeControl>();
        foreach (ChromeControl box in boxes) {
            bool covered = false;
            for (int index = result.Count - 1; index >= 0; index--) {
                ChromeControl other = result[index];
                bool inside = box.x >= other.x && box.y >= other.y && box.x + box.width <= other.x + other.width
                    && box.y + box.height <= other.y + other.height;
                bool contains = other.x >= box.x && other.y >= box.y && other.x + other.width <= box.x + box.width
                    && other.y + other.height <= box.y + box.height;
                if (inside && (box.kind == other.kind || other.kind == "bookmark")) { covered = true; break; }
                if (contains && (box.kind == other.kind || box.kind == "bookmark")) result.RemoveAt(index);
            }
            if (!covered) result.Add(box);
        }
        return result.GetRange(0, Math.Min(128, result.Count)).ToArray();
    }

    void ReadAutomation(IntPtr window, PageState page, Native.RECT client, Native.RECT chrome) {
        IntPtr previousDpi = IntPtr.Zero;
        try {
            try { previousDpi = Native.SetThreadDpiAwarenessContext(new IntPtr(-4)); }
            catch (EntryPointNotFoundException) { }
            AutomationElement root = AutomationElement.FromHandle(window);
            AutomationElementCollection documents = root.FindAll(TreeScope.Descendants,
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Document));
            System.Windows.Rect documentBounds = System.Windows.Rect.Empty;
            foreach (AutomationElement document in documents) {
                System.Windows.Rect bounds = document.Current.BoundingRectangle;
                if (bounds.Width < 100 || bounds.Height < 80) continue;
                if (Math.Abs(bounds.Height - page.viewportHeight * page.scale) > 12) continue;
                if (Math.Abs(bounds.Bottom - client.Bottom) > 12) continue;
                if (documentBounds.IsEmpty || bounds.Width > documentBounds.Width) documentBounds = bounds;
            }
            if (documentBounds.IsEmpty) return;
            int height = (int)Math.Round(documentBounds.Top - chrome.Top);
            if (height < 20 || height > 600) return;
            chrome.Bottom = chrome.Top + height;
            double scale = Math.Max(.65, Math.Min(2.5, height / 118.0));
            var boxes = new List<ChromeControl>();
            AutomationElementCollection elements = root.FindAll(TreeScope.Descendants, new OrCondition(
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit),
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.TabItem),
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.MenuItem),
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Hyperlink),
                new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem)));
            int addressBottom = 0;
            foreach (AutomationElement element in elements) {
                System.Windows.Rect bounds = element.Current.BoundingRectangle;
                ControlType type = element.Current.ControlType;
                if (type == ControlType.Edit && bounds.Width > 160 * scale && InChrome(bounds, chrome))
                    addressBottom = Math.Max(addressBottom, (int)Math.Round(bounds.Bottom - chrome.Top));
            }
            foreach (AutomationElement element in elements) {
                System.Windows.Rect bounds = element.Current.BoundingRectangle;
                if (!InChrome(bounds, chrome)) continue;
                ControlType type = element.Current.ControlType;
                if (BookmarkItem(bounds, chrome, addressBottom, scale)) {
                    AutomationElement ancestor = element;
                    for (int depth = 0; depth < 4; depth++) {
                        ancestor = TreeWalker.ControlViewWalker.GetParent(ancestor);
                        if (ancestor == null) break;
                        ControlType parentType = ancestor.Current.ControlType;
                        if (parentType == ControlType.ToolBar || parentType == ControlType.MenuBar || parentType == ControlType.Window) break;
                        if (parentType == ControlType.Custom && ancestor.FindAll(TreeScope.Children, new OrCondition(
                            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.MenuItem),
                            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Hyperlink),
                            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
                            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.ListItem))).Count > 1) break;
                        if (parentType == ControlType.MenuItem || parentType == ControlType.Button || parentType == ControlType.ListItem
                            || parentType == ControlType.Hyperlink || parentType == ControlType.Custom)
                            bounds = BookmarkParentBounds(bounds, ancestor.Current.BoundingRectangle, chrome, addressBottom, scale);
                    }
                }
                string name = type == ControlType.Edit ? "Edit" : type == ControlType.TabItem ? "TabItem"
                    : type == ControlType.MenuItem ? "MenuItem" : type == ControlType.Hyperlink ? "Hyperlink"
                    : type == ControlType.ListItem ? "ListItem" : "Button";
                ChromeControl box = MapControl(name, bounds, chrome, addressBottom, scale);
                if (box != null) boxes.Add(box);
                if (boxes.Count >= 512) break;
            }
            var result = new AutomationLayout { target = window, clientWidth = client.Right - client.Left,
                clientHeight = client.Bottom - client.Top, viewportWidth = page.viewportWidth,
                viewportHeight = page.viewportHeight, scale = page.scale, captionOffset = client.Top - chrome.Top,
                height = height, controls = DistinctControls(boxes) };
            lock (sync) { if (!closing && target == window && state != null && state.session == page.session) automation = result; }
        } catch (ElementNotAvailableException) { }
          catch (InvalidOperationException) { }
          catch (COMException) { }
          catch (Exception error) { lock (sync) { lastError = "Automation: " + error.GetType().Name; } }
        finally {
            if (previousDpi != IntPtr.Zero) Native.SetThreadDpiAwarenessContext(previousDpi);
            lock (sync) { readingAutomation = false; }
        }
    }

    void Present(byte[] png, Native.RECT bounds) {
        using (var input = new MemoryStream(png, false))
        using (var decoded = new Bitmap(input))
        using (var bitmap = new Bitmap(decoded.Width, decoded.Height, PixelFormat.Format32bppPArgb)) {
            if (decoded.Width != bounds.Right - bounds.Left || decoded.Height != bounds.Bottom - bounds.Top) return;
            using (Graphics graphics = Graphics.FromImage(bitmap)) {
                graphics.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceCopy;
                graphics.DrawImageUnscaled(decoded, 0, 0);
            }
            IntPtr screen = IntPtr.Zero, memory = IntPtr.Zero, handle = IntPtr.Zero, previous = IntPtr.Zero;
            try {
                screen = Native.GetDC(IntPtr.Zero);
                if (screen == IntPtr.Zero) throw new InvalidOperationException("The screen drawing context is unavailable.");
                memory = Native.CreateCompatibleDC(screen);
                if (memory == IntPtr.Zero) throw new InvalidOperationException("The overlay drawing context could not be created.");
                handle = bitmap.GetHbitmap(Color.FromArgb(0));
                previous = Native.SelectObject(memory, handle);
                if (previous == IntPtr.Zero || previous == new IntPtr(-1)) throw new InvalidOperationException("The overlay bitmap could not be selected.");
                var position = new Native.POINT { X = bounds.Left, Y = bounds.Top };
                var size = new Native.SIZE { Width = bitmap.Width, Height = bitmap.Height };
                var source = new Native.POINT();
                var blend = new Native.BLENDFUNCTION { BlendOp = 0, BlendFlags = 0, SourceConstantAlpha = 255, AlphaFormat = 1 };
                if (!Native.UpdateLayeredWindow(Handle, screen, ref position, ref size, memory, ref source, 0, ref blend, 2))
                    throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
            } finally {
                if (memory != IntPtr.Zero && previous != IntPtr.Zero && previous != new IntPtr(-1)) Native.SelectObject(memory, previous);
                if (handle != IntPtr.Zero) Native.DeleteObject(handle);
                if (memory != IntPtr.Zero) Native.DeleteDC(memory);
                if (screen != IntPtr.Zero) Native.ReleaseDC(IntPtr.Zero, screen);
            }
        }
    }

    static class Native {
        [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] public struct SIZE { public int Width, Height; }
        [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential, Pack = 1)] public struct BLENDFUNCTION { public byte BlendOp, BlendFlags, SourceConstantAlpha, AlphaFormat; }
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT point);
        [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int key);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr window);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr window);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr window, StringBuilder text, int count);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
        [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr window, out RECT bounds);
        [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr window, int attribute, out RECT value, int size);
        [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr window, ref POINT point);
        [DllImport("user32.dll")] public static extern uint GetDpiForWindow(IntPtr window);
        [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr value);
        [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr value);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr window, int index);
        [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr window, int id);
        [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr window);
        [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr window, IntPtr dc);
        [DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr dc);
        [DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr dc);
        [DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr dc, IntPtr value);
        [DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr value);
        [DllImport("user32.dll", SetLastError = true)] public static extern bool UpdateLayeredWindow(IntPtr window, IntPtr dc,
            ref POINT destination, ref SIZE size, IntPtr sourceDc, ref POINT source, int colorKey, ref BLENDFUNCTION blend, int flags);
    }
}
}

