param([int]$Port = 0, [switch]$NoBrowser, [switch]$Overlay, [switch]$DebugMode, [string]$Root = (Join-Path $PSScriptRoot 'game'), [switch]$OnlineOverlay)
$ErrorActionPreference = 'Stop'
if ($OnlineOverlay -and $DebugMode) { throw 'The online launcher only supports exhibition mode.' }
$showOverlay = $Overlay -or $OnlineOverlay

# Only Windows' built-in .NET runtime is needed. Listen on loopback without
# HttpListener URL reservations, installed packages, or administrator rights.
$serverSource = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public interface IPatchOverlay {
    string State(string json);
    bool Frame(byte[] png, string session, string revision);
    string Diagnostics();
}

public sealed class PatchGameServer : IDisposable {
    const string OnlineOrigin = "https://pancakecivet.github.io";
    const string OnlinePage = OnlineOrigin + "/a-small-patch-exhibition/";
    const string OnlineCors = "Access-Control-Allow-Origin: " + OnlineOrigin + "\r\nVary: Origin\r\n";
    readonly TcpListener listener;
    readonly string root;
    readonly bool onlineOverlay;
    readonly string authority;
    readonly int listenerPort;
    readonly IPatchOverlay overlay;
    readonly string token;
    volatile bool stopped;
    public string Url { get; private set; }

    public PatchGameServer(string directory, int port) : this(directory, port, null) { }

    public PatchGameServer(string directory, int port, IPatchOverlay browserOverlay) : this(directory, port, browserOverlay, false) { }

    public PatchGameServer(string directory, int port, IPatchOverlay browserOverlay, bool useOnlineOverlay) {
        onlineOverlay = useOnlineOverlay;
        if (!onlineOverlay) {
            root = Path.GetFullPath(directory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!File.Exists(Path.Combine(root, "index.html"))) throw new FileNotFoundException("The game folder is missing. Extract the entire ZIP first.");
        }
        listener = new TcpListener(IPAddress.Loopback, port);
        listener.Start();
        listenerPort = ((IPEndPoint)listener.LocalEndpoint).Port;
        authority = "127.0.0.1:" + listenerPort;
        Url = "http://" + authority + "/";
        overlay = browserOverlay;
        if (overlay != null) token = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N");
        var thread = new Thread(Accept);
        thread.IsBackground = true;
        thread.Start();
    }

    public string LaunchUrl {
        get {
            if (onlineOverlay) return OnlinePage + "#overlayPort=" + listenerPort + "&overlayToken=" + token;
            return overlay == null ? Url : Url + "?browserOverlay=" + token;
        }
    }

    void Accept() {
        while (!stopped) {
            try {
                TcpClient client = listener.AcceptTcpClient();
                ThreadPool.QueueUserWorkItem(delegate { Serve(client); });
            } catch (SocketException) { if (stopped) return; }
              catch (ObjectDisposedException) { return; }
        }
    }

    static void Header(Stream output, int status, string reason, string type, long length, string extra) {
        byte[] data = Encoding.ASCII.GetBytes("HTTP/1.1 " + status + " " + reason + "\r\nContent-Type: " + type + "\r\nContent-Length: " + length + "\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n" + extra + "\r\n");
        output.Write(data, 0, data.Length);
    }

    static string Mime(string file) {
        switch (Path.GetExtension(file).ToLowerInvariant()) {
            case ".html": return "text/html; charset=utf-8";
            case ".js": case ".mjs": return "text/javascript; charset=utf-8";
            case ".css": return "text/css; charset=utf-8";
            case ".json": return "application/json; charset=utf-8";
            case ".svg": return "image/svg+xml";
            case ".png": return "image/png";
            case ".mp3": return "audio/mpeg";
            case ".mp4": return "video/mp4";
            case ".woff2": return "font/woff2";
            case ".wasm": return "application/wasm";
            case ".md": case ".txt": return "text/plain; charset=utf-8";
            default: return "application/octet-stream";
        }
    }

    static void Json(Stream output, string value, string extra = "") {
        byte[] data = Encoding.UTF8.GetBytes(value);
        Header(output, 200, "OK", "application/json; charset=utf-8", data.Length, extra);
        output.Write(data, 0, data.Length);
    }

    static Dictionary<string, string> Query(string path) {
        var result = new Dictionary<string, string>();
        int question = path.IndexOf('?');
        if (question < 0) return result;
        foreach (string parameter in path.Substring(question + 1).Split('&')) {
            int equal = parameter.IndexOf('=');
            if (equal > 0) result[Uri.UnescapeDataString(parameter.Substring(0, equal))]
                = Uri.UnescapeDataString(parameter.Substring(equal + 1));
        }
        return result;
    }

    bool OverlayRequest(NetworkStream stream, string method, string target, Dictionary<string, string> headers) {
        if (!target.StartsWith("/__overlay/", StringComparison.Ordinal)) return false;
        if (overlay == null) { Header(stream, 404, "Not Found", "text/plain", 0, ""); return true; }
        Dictionary<string, string> query = Query(target);
        string suppliedToken, origin, host;
        headers.TryGetValue("origin", out origin);
        bool validOrigin = onlineOverlay
            ? origin == OnlineOrigin && headers.TryGetValue("host", out host) && host == authority
            : origin == null || origin == Url.TrimEnd('/');
        if (!query.TryGetValue("token", out suppliedToken) || suppliedToken != token || !validOrigin) {
            Header(stream, 403, "Forbidden", "text/plain", 0, ""); return true;
        }
        string cors = onlineOverlay ? OnlineCors : "";
        string route = target.Split('?')[0];
        if (!onlineOverlay && route == "/__overlay/diagnostics" && method == "GET") { Json(stream, overlay.Diagnostics()); return true; }
        if (route != "/__overlay/state" && route != "/__overlay/frame") {
            Header(stream, 404, "Not Found", "text/plain", 0, cors); return true;
        }
        if (onlineOverlay && method == "OPTIONS") {
            string requestedMethod;
            if (!headers.TryGetValue("access-control-request-method", out requestedMethod) || requestedMethod != "POST") {
                Header(stream, 405, "Method Not Allowed", "text/plain", 0, ""); return true;
            }
            Header(stream, 204, "No Content", "text/plain", 0, cors + "Access-Control-Allow-Methods: POST\r\nAccess-Control-Allow-Headers: Content-Type\r\nAccess-Control-Allow-Private-Network: true\r\nAccess-Control-Max-Age: 600\r\n");
            return true;
        }
        if (method != "POST") { Header(stream, 405, "Method Not Allowed", "text/plain", 0, cors + "Allow: POST\r\n"); return true; }
        string lengthHeader, contentType;
        int length;
        int limit = route == "/__overlay/state" ? 8192 : 8388608;
        if (!headers.TryGetValue("content-length", out lengthHeader) || !Int32.TryParse(lengthHeader, out length) || length < 1) {
            Header(stream, 411, "Length Required", "text/plain", 0, cors); return true;
        }
        if (length > limit) { Header(stream, 413, "Payload Too Large", "text/plain", 0, cors); return true; }
        string requiredType = route == "/__overlay/state" ? "application/json" : "image/png";
        if (!headers.TryGetValue("content-type", out contentType) || !contentType.StartsWith(requiredType, StringComparison.OrdinalIgnoreCase)) {
            Header(stream, 415, "Unsupported Media Type", "text/plain", 0, cors); return true;
        }
        byte[] body = new byte[length];
        int offset = 0;
        while (offset < body.Length) {
            int received = stream.Read(body, offset, body.Length - offset);
            if (received == 0) return true;
            offset += received;
        }
        try {
            if (route == "/__overlay/state") Json(stream, overlay.State(Encoding.UTF8.GetString(body)), cors);
            else {
                string session, revision;
                if (!query.TryGetValue("session", out session) || !query.TryGetValue("revision", out revision)) {
                    Header(stream, 400, "Bad Request", "text/plain", 0, cors); return true;
                }
                bool accepted = overlay.Frame(body, session, revision);
                Header(stream, accepted ? 204 : 409, accepted ? "No Content" : "Conflict", "text/plain", 0, cors);
            }
        } catch (ArgumentException) { Header(stream, 400, "Bad Request", "text/plain", 0, cors); }
        return true;
    }

    void Serve(TcpClient client) {
        using (client) {
            try {
                client.ReceiveTimeout = client.SendTimeout = 10000;
                using (NetworkStream output = client.GetStream()) {
                    var request = new StringBuilder();
                    while (request.Length < 16384) {
                        int value = output.ReadByte();
                        if (value < 0) return;
                        request.Append((char)value);
                        int n = request.Length;
                        if (n >= 4 && request[n-4]=='\r' && request[n-3]=='\n' && request[n-2]=='\r' && request[n-1]=='\n') break;
                    }
                    if (request.Length >= 16384) { Header(output, 431, "Request Header Fields Too Large", "text/plain", 0, ""); return; }
                    string[] lines = request.ToString().Split(new string[] { "\r\n" }, StringSplitOptions.None);
                    string[] first = lines[0].Split(' ');
                    if (first.Length != 3 || !first[1].StartsWith("/")) { Header(output, 400, "Bad Request", "text/plain", 0, ""); return; }
                    var headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    foreach (string line in lines) {
                        int colon = line.IndexOf(':');
                        if (colon > 0) headers[line.Substring(0, colon).Trim()] = line.Substring(colon + 1).Trim();
                    }
                    if (OverlayRequest(output, first[0], first[1], headers)) return;
                    if (onlineOverlay) { Header(output, 404, "Not Found", "text/plain", 0, ""); return; }
                    bool head = first[0] == "HEAD";
                    if (!head && first[0] != "GET") { Header(output, 405, "Method Not Allowed", "text/plain", 0, "Allow: GET, HEAD\r\n"); return; }
                    string relative = Uri.UnescapeDataString(first[1].Split('?')[0]).TrimStart('/');
                    if (relative == "") relative = "index.html";
                    string file = Path.GetFullPath(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
                    if (!file.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(file)) { Header(output, 404, "Not Found", "text/plain", 0, ""); return; }
                    using (FileStream input = File.OpenRead(file)) {
                        long start = 0, end = input.Length - 1;
                        bool partial = false;
                        foreach (string line in lines) if (line.StartsWith("Range:", StringComparison.OrdinalIgnoreCase)) {
                            string range = line.Substring(6).Trim();
                            if (!range.StartsWith("bytes=") || range.Contains(",")) { Header(output, 416, "Range Not Satisfiable", "text/plain", 0, "Content-Range: bytes */" + input.Length + "\r\n"); return; }
                            string[] parts = range.Substring(6).Split('-');
                            long value;
                            bool valid = parts.Length == 2;
                            if (valid && parts[0] == "") {
                                valid = long.TryParse(parts[1], out value) && value > 0;
                                if (valid) start = Math.Max(0, input.Length - value);
                            } else if (valid) {
                                valid = long.TryParse(parts[0], out start);
                                if (valid && parts[1] != "") { valid = long.TryParse(parts[1], out end); end = Math.Min(end, input.Length - 1); }
                            }
                            if (!valid || start < 0 || start > end || start >= input.Length) { Header(output, 416, "Range Not Satisfiable", "text/plain", 0, "Content-Range: bytes */" + input.Length + "\r\n"); return; }
                            partial = true; break;
                        }
                        long remaining = Math.Max(0, end - start + 1);
                        string extra = "Accept-Ranges: bytes\r\n";
                        if (partial) extra += "Content-Range: bytes " + start + "-" + end + "/" + input.Length + "\r\n";
                        Header(output, partial ? 206 : 200, partial ? "Partial Content" : "OK", Mime(file), remaining, extra);
                        if (head) return;
                        input.Position = start;
                        byte[] buffer = new byte[65536];
                        while (remaining > 0) {
                            int count = input.Read(buffer, 0, (int)Math.Min(buffer.Length, remaining));
                            if (count == 0) break;
                            output.Write(buffer, 0, count); remaining -= count;
                        }
                    }
                }
            } catch (IOException) { }
              catch (ArgumentException) { }
              catch (UnauthorizedAccessException) { }
        }
    }

    public void Dispose() { stopped = true; listener.Stop(); }
}
'@

$references = @('System.dll', 'System.Core.dll')
$browserOverlay = $null
if ($showOverlay) {
    $assemblies = @('System.Windows.Forms', 'System.Drawing', 'System.Web.Extensions', 'WindowsBase', 'UIAutomationClient', 'UIAutomationTypes')
    foreach ($assembly in $assemblies) {
        Add-Type -AssemblyName $assembly
        $references += [Reflection.Assembly]::LoadWithPartialName($assembly).Location
    }
    $nativeSource = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'browser-overlay.cs') -Raw
    Add-Type -TypeDefinition ($serverSource + [Environment]::NewLine + $nativeSource) -ReferencedAssemblies $references
    [SmallPatch.PatchBrowserOverlay]::EnableDpiAwareness()
    $browserOverlay = [SmallPatch.PatchBrowserOverlay]::new()
} else {
    Add-Type -TypeDefinition $serverSource -ReferencedAssemblies $references
}
$server = [PatchGameServer]::new($Root, $Port, $browserOverlay, [bool]$OnlineOverlay)
$launchUrl = $server.LaunchUrl
if ($DebugMode) {
    $separator = if ($launchUrl.Contains('?')) { '&' } else { '?' }
    $launchUrl += "${separator}mode=debug"
}
if ($OnlineOverlay) { Write-Host 'A Small Patch - online exhibition overlay' }
else { Write-Host 'A Small Patch - local game' }
if (-not $OnlineOverlay -or $NoBrowser) { Write-Host $launchUrl }
Write-Host 'Keep this window open while playing. Close it to stop.'
if ($showOverlay) { Write-Host 'Browser overlay enabled. Ctrl+Alt+F10 closes this local session.' }
else { Write-Host 'Ctrl+C also stops this local session.' }
try {
    if (-not $NoBrowser) {
        if ($showOverlay) {
            $edgePath = Join-Path ${env:ProgramFiles(x86)} 'Microsoft/Edge/Application/msedge.exe'
            if (-not (Test-Path -LiteralPath $edgePath)) { $edgePath = Join-Path $env:ProgramFiles 'Microsoft/Edge/Application/msedge.exe' }
            if (-not (Test-Path -LiteralPath $edgePath)) { throw 'Microsoft Edge was not found. Start with -NoBrowser and open the printed URL in Edge.' }
            Start-Process -FilePath $edgePath -ArgumentList @('--new-window', $launchUrl)
        } else { Start-Process $launchUrl }
    }
    if ($showOverlay) { [System.Windows.Forms.Application]::Run($browserOverlay) }
    else { while ($true) { Start-Sleep -Milliseconds 500 } }
} finally {
    $server.Dispose()
    if ($null -ne $browserOverlay) { $browserOverlay.Dispose() }
}
