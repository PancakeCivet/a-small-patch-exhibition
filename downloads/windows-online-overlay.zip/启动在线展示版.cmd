@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0scripts\game-server.ps1" -OnlineOverlay
if errorlevel 1 pause
